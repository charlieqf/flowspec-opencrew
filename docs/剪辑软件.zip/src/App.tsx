import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, MousePointer2, Scissors, Undo, Redo, Maximize2, Minus, Plus, Volume2, Eye, Lock, MonitorPlay, Settings, SplitSquareHorizontal } from 'lucide-react';

const TOTAL_SECONDS = 10;

const initialShots = [
  {
    id: '1',
    title: '1. 渐进揭示',
    start: 0,
    duration: 3.7,
    selected: true,
    keyframes: [
      { id: 'K1', time: 0, selected: true },
      { id: 'K2', time: 2.0, selected: false },
      { id: 'K3', time: 3.7, selected: false },
    ]
  },
  {
    id: '2',
    title: '2. 情感升华',
    start: 3.7,
    duration: 5.0,
    selected: false,
    keyframes: [
      { id: 'K4', time: 3.7, selected: false },
      { id: 'K5', time: 6.2, selected: false },
      { id: 'K6', time: 8.7, selected: false },
    ]
  }
];

export default function App() {
  const [currentTime, setCurrentTime] = useState(0);
  const [scale, setScale] = useState(150);
  const [isDragging, setIsDragging] = useState(false);
  const timelineRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();
    const animate = (time: number) => {
      if (isPlaying) {
        const delta = (time - lastTime) / 1000;
        setCurrentTime(prev => {
          const next = prev + delta;
          if (next >= TOTAL_SECONDS) {
            setIsPlaying(false);
            return 0;
          }
          return next;
        });
      }
      lastTime = time;
      animationFrameId = requestAnimationFrame(animate);
    };
    if (isPlaying) {
      animationFrameId = requestAnimationFrame(animate);
    }
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying]);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (!timelineRef.current) return;
    setIsDragging(true);
    updatePlayhead(e.clientX);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !timelineRef.current) return;
    updatePlayhead(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
  };

  const updatePlayhead = (clientX: number) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const scrollLeft = timelineRef.current.scrollLeft;
    const x = clientX - rect.left + scrollLeft;
    let newTime = x / scale;
    newTime = Math.max(0, Math.min(newTime, TOTAL_SECONDS));
    setCurrentTime(newTime);
  };

  const formatTimecode = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    const frames = Math.floor((time % 1) * 30);
    return `00:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}:${frames.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-screen w-full bg-[#0a0a0a] text-zinc-300 flex flex-col font-sans overflow-hidden select-none">
      <header className="h-10 border-b border-zinc-800/80 bg-[#111111] flex items-center px-4 shrink-0 text-xs text-zinc-400">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-zinc-200 font-semibold">
            <div className="w-5 h-5 bg-indigo-600 rounded flex items-center justify-center shadow-sm shadow-indigo-500/20">
              <MonitorPlay size={12} className="text-white" />
            </div>
            <span>NovaEdit Pro</span>
          </div>
          <nav className="flex items-center gap-4">
            <span className="hover:text-zinc-100 cursor-pointer">File</span>
            <span className="hover:text-zinc-100 cursor-pointer">Edit</span>
            <span className="hover:text-zinc-100 cursor-pointer">Timeline</span>
            <span className="hover:text-zinc-100 cursor-pointer">View</span>
            <span className="hover:text-zinc-100 cursor-pointer">Window</span>
          </nav>
        </div>
      </header>

      <div className="h-12 border-b border-zinc-800/80 bg-[#14151a] flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-1">
          <ToolButton icon={<MousePointer2 size={16} />} active tooltip="Selection Tool (V)" />
          <ToolButton icon={<Scissors size={16} />} tooltip="Blade Tool (C)" />
          <div className="w-px h-5 bg-zinc-800 mx-2" />
          <ToolButton icon={<Undo size={16} />} tooltip="Undo (Ctrl+Z)" />
          <ToolButton icon={<Redo size={16} />} tooltip="Redo (Ctrl+Shift+Z)" />
        </div>
        
        <div className="flex items-center gap-4">
          <div className="font-mono text-sm bg-black/60 px-3 py-1.5 rounded border border-zinc-800/80 text-indigo-400 shadow-inner">
            {formatTimecode(currentTime)}
          </div>
          <div className="flex items-center gap-1 bg-zinc-900/50 p-1 rounded-lg border border-zinc-800/50">
            <button className="p-1.5 hover:bg-zinc-700/50 rounded text-zinc-400 hover:text-zinc-100 transition-colors" onClick={() => setCurrentTime(0)}>
              <SkipBack size={16} fill="currentColor" />
            </button>
            <button 
              className="p-1.5 hover:bg-zinc-700/50 rounded text-zinc-200 hover:text-white transition-colors"
              onClick={() => setIsPlaying(!isPlaying)}
            >
              {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
            </button>
            <button className="p-1.5 hover:bg-zinc-700/50 rounded text-zinc-400 hover:text-zinc-100 transition-colors" onClick={() => setCurrentTime(TOTAL_SECONDS)}>
              <SkipForward size={16} fill="currentColor" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
           <ToolButton icon={<Settings size={16} />} tooltip="Settings" />
        </div>
      </div>

      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 flex border-b border-zinc-800/80 min-h-0 bg-[#0a0a0a]">
           <div className="flex-1 flex flex-col p-4">
              <div className="flex-1 bg-black rounded-lg border border-zinc-800/80 flex items-center justify-center relative shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 to-black flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-zinc-700 font-mono text-sm mb-2">PROGRAM MONITOR</div>
                    <div className="text-zinc-500 font-mono text-2xl">{formatTimecode(currentTime)}</div>
                  </div>
                </div>
              </div>
           </div>
           
           <div className="w-80 bg-[#111111] border-l border-zinc-800/80 flex flex-col">
             <div className="h-10 border-b border-zinc-800/80 flex items-center px-4 bg-[#14151a]">
               <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">Inspector</span>
             </div>
             <div className="p-4 flex flex-col gap-4 overflow-y-auto">
               <InspectorSection title="Transform" active>
                 <div className="grid grid-cols-2 gap-3">
                   <InspectorInput label="Position X" value="0.0" />
                   <InspectorInput label="Position Y" value="0.0" />
                   <InspectorInput label="Scale" value="100%" />
                   <InspectorInput label="Rotation" value="0.0°" />
                 </div>
               </InspectorSection>
               <InspectorSection title="Opacity" active>
                 <div className="flex items-center gap-3">
                   <input type="range" className="flex-1 accent-indigo-500" defaultValue="100" />
                   <span className="text-xs font-mono text-zinc-400 w-8 text-right">100%</span>
                 </div>
               </InspectorSection>
             </div>
           </div>
        </div>

        <div className="h-[340px] bg-[#14151a] flex flex-col shrink-0">
          <div className="h-9 border-b border-zinc-800/80 bg-[#1a1b20] flex items-center justify-between px-4 shrink-0">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-zinc-900/50 px-3 py-1 rounded border border-zinc-800/50">
                <SplitSquareHorizontal size={14} className="text-indigo-400" />
                <span className="text-xs font-medium text-zinc-300">Main Sequence</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-zinc-900/50 px-2 py-1 rounded border border-zinc-800/50">
                <button className="text-zinc-500 hover:text-zinc-300 transition-colors" onClick={() => setScale(s => Math.max(50, s - 20))}><Minus size={14} /></button>
                <input 
                  type="range" min="50" max="300" value={scale} 
                  onChange={(e) => setScale(Number(e.target.value))} 
                  className="w-24 h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-indigo-500" 
                />
                <button className="text-zinc-500 hover:text-zinc-300 transition-colors" onClick={() => setScale(s => Math.min(300, s + 20))}><Plus size={14} /></button>
              </div>
              <button className="p-1 hover:bg-zinc-700/50 rounded text-zinc-400 transition-colors"><Maximize2 size={14} /></button>
            </div>
          </div>

          <div className="flex-1 flex min-h-0 relative">
            <div className="w-56 bg-[#1a1b20] border-r border-zinc-800/80 flex flex-col shrink-0 z-20 shadow-[4px_0_12px_rgba(0,0,0,0.2)]">
              <div className="h-8 border-b border-zinc-800/80 bg-[#14151a]" />
              <div className="flex-1 overflow-y-auto custom-scrollbar">
                <TrackHeader name="V2" />
                <TrackHeader name="V1" active />
                <div className="h-2 border-b border-zinc-800/80 bg-[#111111]" />
                <TrackHeader name="A1" isAudio />
                <TrackHeader name="A2" isAudio />
              </div>
            </div>

            <div 
              className="flex-1 overflow-auto custom-scrollbar relative bg-[#111111]" 
              ref={timelineRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
            >
              <div style={{ width: `${TOTAL_SECONDS * scale + 100}px`, minWidth: '100%' }} className="h-full relative">
                <div className="absolute inset-0 pointer-events-none flex">
                  {Array.from({ length: TOTAL_SECONDS + 1 }).map((_, i) => (
                    <div key={i} className="absolute top-0 bottom-0 border-l border-zinc-800/30" style={{ left: `${i * scale}px` }} />
                  ))}
                </div>

                <Ruler pixelsPerSecond={scale} duration={TOTAL_SECONDS} />
                
                <div className="absolute top-8 bottom-0 left-0 right-0 flex flex-col">
                  <TrackRow />
                  <TrackRow hasClips>
                    {initialShots.map(shot => (
                      <Clip key={shot.id} shot={shot} pixelsPerSecond={scale} />
                    ))}
                  </TrackRow>
                  <div className="h-2 border-b border-zinc-800/80 bg-[#0a0a0a]" />
                  <TrackRow />
                  <TrackRow />
                </div>

                <Playhead time={currentTime} pixelsPerSecond={scale} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const ToolButton = ({ icon, active, tooltip }: { icon: React.ReactNode, active?: boolean, tooltip?: string }) => (
  <button 
    className={`p-1.5 rounded transition-all duration-200 ${
      active 
        ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/20' 
        : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100'
    }`}
    title={tooltip}
  >
    {icon}
  </button>
);

const TrackHeader = ({ name, active, isAudio }: { name: string, active?: boolean, isAudio?: boolean }) => (
  <div className={`h-[72px] border-b border-zinc-800/80 flex flex-col justify-center px-3 gap-2 transition-colors ${active ? 'bg-zinc-800/30' : 'hover:bg-zinc-800/10'}`}>
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className={`w-1.5 h-1.5 rounded-full ${active ? 'bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.8)]' : 'bg-zinc-700'}`} />
        <span className={`text-xs font-bold ${active ? 'text-zinc-200' : 'text-zinc-500'}`}>{name}</span>
      </div>
      <div className="flex gap-1.5">
        <button className="text-zinc-600 hover:text-zinc-300 transition-colors"><Lock size={14} /></button>
        <button className="text-zinc-600 hover:text-zinc-300 transition-colors">{isAudio ? <Volume2 size={14} /> : <Eye size={14} />}</button>
      </div>
    </div>
  </div>
);

const TrackRow = ({ children, hasClips }: { children?: React.ReactNode, hasClips?: boolean }) => (
  <div className={`h-[72px] border-b border-zinc-800/50 relative ${hasClips ? 'bg-zinc-900/20' : ''}`}>
    {children}
  </div>
);

const Ruler = ({ pixelsPerSecond, duration }: { pixelsPerSecond: number, duration: number }) => {
  const ticks = [];
  for (let i = 0; i <= duration; i++) {
    ticks.push(
      <div key={`major-${i}`} className="absolute top-0 bottom-0 border-l border-zinc-700" style={{ left: `${i * pixelsPerSecond}px` }}>
        <span className="absolute top-1 left-1.5 text-[10px] text-zinc-400 font-mono select-none">{i}s</span>
      </div>
    );
    if (i < duration) {
      for (let j = 1; j < 10; j++) {
        const isHalf = j === 5;
        ticks.push(
          <div 
            key={`minor-${i}-${j}`} 
            className={`absolute bottom-0 border-l ${isHalf ? 'h-2.5 border-zinc-600' : 'h-1.5 border-zinc-700/50'}`} 
            style={{ left: `${(i + j/10) * pixelsPerSecond}px` }} 
          />
        );
      }
    }
  }
  return (
    <div className="relative h-8 bg-[#1a1b20] border-b border-zinc-800/80 sticky top-0 z-30">
      {ticks}
    </div>
  );
};

const Playhead = ({ time, pixelsPerSecond }: { time: number, pixelsPerSecond: number }) => {
  const left = time * pixelsPerSecond;
  return (
    <div className="absolute top-0 bottom-0 z-50 pointer-events-none" style={{ left: `${left}px` }}>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3.5 h-4 bg-indigo-500 pointer-events-auto cursor-ew-resize flex flex-col items-center shadow-md" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 60%, 50% 100%, 0 60%)' }} />
      <div className="absolute top-4 bottom-0 left-1/2 -translate-x-1/2 w-px bg-indigo-500 shadow-[0_0_6px_rgba(99,102,241,0.6)]" />
    </div>
  );
};

const Clip = ({ shot, pixelsPerSecond }: { shot: any, pixelsPerSecond: number }) => {
  const width = shot.duration * pixelsPerSecond;
  const left = shot.start * pixelsPerSecond;

  return (
    <div
      className={`absolute top-2 bottom-2 rounded-lg border ${
        shot.selected 
          ? 'border-indigo-500 bg-gradient-to-b from-indigo-900/40 to-indigo-900/10 z-10 shadow-[0_0_15px_rgba(99,102,241,0.15)]' 
          : 'border-zinc-700 bg-gradient-to-b from-zinc-800/60 to-zinc-900/60 z-0'
      } overflow-visible group cursor-pointer transition-all`}
      style={{ left: `${left}px`, width: `${width}px` }}
    >
      <div className="absolute -top-3 left-2 bg-[#0a0a0a] px-2 py-0.5 rounded border border-zinc-800 shadow-sm flex items-center z-20">
        <span className={`text-[11px] font-medium ${shot.selected ? 'text-zinc-100' : 'text-zinc-400'}`}>
          {shot.title}
        </span>
      </div>

      <div className="absolute -top-3 right-2 bg-[#0a0a0a] px-2 py-0.5 rounded border border-zinc-800 shadow-sm flex items-center z-20">
        <span className="text-[10px] font-mono text-zinc-500">
          {shot.duration.toFixed(1)}s
        </span>
      </div>

      <div className="w-full h-full relative overflow-hidden rounded-md">
        <div className="absolute inset-0 opacity-[0.02] bg-[linear-gradient(45deg,#fff_25%,transparent_25%,transparent_75%,#fff_75%,#fff_100%),linear-gradient(45deg,#fff_25%,transparent_25%,transparent_75%,#fff_75%,#fff_100%)]" style={{ backgroundSize: '8px 8px', backgroundPosition: '0 0, 4px 4px' }} />
        
        <div className="absolute bottom-3.5 left-0 right-0 h-px bg-zinc-700/50" />

        {shot.keyframes.map((kf: any) => {
          const kfLeft = (kf.time - shot.start) * pixelsPerSecond;
          return (
            <div key={kf.id} className="absolute bottom-3.5" style={{ left: `${kfLeft}px`, transform: 'translate(-50%, 50%)' }}>
              <span className={`absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-mono ${kf.selected ? 'text-indigo-300 font-bold' : 'text-zinc-500'}`}>
                {kf.id}
              </span>
              <div className={`w-2.5 h-2.5 rotate-45 border transition-all ${
                kf.selected 
                  ? 'bg-indigo-500 border-indigo-300 shadow-[0_0_8px_rgba(99,102,241,0.6)] scale-110' 
                  : 'bg-[#1a1b20] border-zinc-500 group-hover:border-zinc-400'
              }`} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

const InspectorSection = ({ title, active, children }: { title: string, active?: boolean, children: React.ReactNode }) => (
  <div className="bg-zinc-900/50 rounded-lg border border-zinc-800/80 overflow-hidden">
    <div className="px-3 py-2 flex justify-between items-center bg-zinc-800/30 border-b border-zinc-800/80 cursor-pointer hover:bg-zinc-800/50 transition-colors">
      <span className="text-xs font-medium text-zinc-300">{title}</span>
      <div className={`w-2 h-2 rounded-full ${active ? 'bg-indigo-500 shadow-[0_0_6px_rgba(99,102,241,0.6)]' : 'bg-zinc-700'}`} />
    </div>
    <div className="p-3">
      {children}
    </div>
  </div>
);

const InspectorInput = ({ label, value }: { label: string, value: string }) => (
  <div className="flex flex-col gap-1">
    <span className="text-[10px] text-zinc-500 uppercase">{label}</span>
    <div className="bg-black border border-zinc-800 rounded px-2 py-1 text-xs font-mono text-zinc-300 hover:border-zinc-600 transition-colors cursor-text">
      {value}
    </div>
  </div>
);
